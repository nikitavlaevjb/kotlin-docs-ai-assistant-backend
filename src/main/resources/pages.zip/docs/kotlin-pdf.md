[//]: # (title: Kotlin documentation as PDF)

Here you can download a PDF version of Kotlin documentation that includes everything except tutorials and API reference.

**[Download Kotlin 2.2.20 documentation (PDF)](https://kotlinlang.org/docs/kotlin-reference.pdf)**

**[View the latest Kotlin documentation (online)](home.topic)**